# Atlas v0.3 – ekte kart

Denne versjonen erstatter det illustrerte kartet med et ekte OpenStreetMap-kart.

Inneholder:
- korrekt geografi
- panorering og zoom
- GPS
- artsvelger
- kartlag
- demomarkører
- Atlas Score-hotspots
- områdekort
- navigasjon til demo-område
- design nærmere mockupen

Alle artsdata og scorer er fortsatt demonstrasjonsdata.
